from Tkinter import Tk, Label, Button
import VL53L0X
import time
# Create a VL53L0X object
tof = VL53L0X.VL53L0X()
# Start ranging
tof.start_ranging(VL53L0X.VL53L0X_BETTER_ACCURACY_MODE)

class MyFirstGUI:
    def __init__(self, master):
        self.master = master
        master.title("A simple GUI")
        master.configure(background='yellow')
        master.attributes("-fullscreen", True)

        self.label = Label(master, text="This is our first GUI!")
        self.label.pack()

        self.greet_button = Button(master, text="Greet", command=self.greet)
        self.greet_button.pack()

        self.close_button = Button(master, text="Close", command=master.quit)
        self.close_button.pack()

    def greet(self):
        i = 0
        distance = tof.get_distance()
        while i < 10:
            distance = tof.get_distance()
            if (distance < 50):
                Result = Label()
                Result.config(font=('times', 30, 'italic'))
                Result.place(x=100, y=300)  
                Result.config(text='WARNING!!!')
                print ("%d mm, %d cm" % (distance, (distance / 10)))
            else:
                Result.destroy()
            i = i + 1
            time.sleep(0.1)
            


root = Tk()
my_gui = MyFirstGUI(root)
root.mainloop()





